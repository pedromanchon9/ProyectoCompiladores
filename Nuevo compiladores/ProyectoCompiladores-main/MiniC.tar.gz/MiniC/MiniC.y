%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Declaraciones de funciones externas de Flex */

extern int yylex();
extern int yylineno;
extern char* yytext;

/* Para el control de errores */


void yyerror(const char *msg);
extern int errores = 0;

//Listas de elementos
    Lista l;
    Tipo t;
    void declarar_id();
    void 

%}

%union {
   string cadena;
}

%token <cadena> ID      "id"
%token <cadena> NUM     "num"
%token <cadena> STR     "string"

/* Palabras reservadas */
%token VOID              "void"
%token VAR               "var"
%token CONST             "const"
%token IF                 "if"
%token ELSE               "else"
%token WHILE              "while"
%token PRINT              "print"
%token READ               "read"
%token INT                "int"
%token SUMA "+"
%token REST "-"
%token IGU "="
%token PYC ";"
%token COMA ","
%token PAI "("
%token PAD ")"
%token LLI "{"
%token LLD "}"

%left '+' '-'     
%left '*' '/'      
%precedence UMINUS 

%precedence NOELSE
%precendece ELSE

%define parse.error verbose 

%define parse.trace

%%

/* 

program:    {l = creaLS(); } VOID ID "(" ")" "{" body "}"       { 
                if(errores == 0) {
                    imprimir_ls();
                }
                liberaLS(l);
            }   
    ;

body:
    | body declaration                { }
    | body statement                  { }
    | %empty                          { }
    ;

declaration:
    | VAR        { t = VARIABLE; } tipo id_list ";"         { }
    | CONST     { t = CONSTANTE; } tipo id_list ";"          { }
    ;

tipo:
      INT                             { }
    ;

id_list:
      id_decl                         { }
    | id_list COMA id_decl            { }
    ;

id_decl:
      ID                { declarar_id($1,t); }
    | ID IGU expression { declarar_id($1,t); }
    ;

statement:
    ...

statement_list:
    ...

print_list:
    ...

print_item:
    ...

read_list:
    ...

expression:
    ...

%%


void yyerror(const char *msg) {
    fprintf(stderr, "Error sintáctico en línea %d: %s\n", yylineno, msg);
    errores++;
}

void declarar_id( char *id, Tipo t){
    PosicionLista p = buscaLS(l,id);
    if(p != finalLS(l)) {
        errores++;
        printf("Errores en linea %d: %s redeclarador \n", yylineno, id);
    }
    else{

        Simbolo s;
        s.nombre = id;
        s.tipo = t;
        s.valor = 0;
        insertaLS(l,finalLS(l),s);

    }
}

 void imprimir_ls(){
    PosicionLista p = inicioLS(l);
    while (p != finalLS(l)){
        Simbolo aux = recuperaLS(l,p);
        if (aux.tipo == VARIABLE || aux.tipo == CONSTANTE) {
            printf("_%s: .word %d\n", aux.nombre, aux.valor);
        }
            p = siguienteLS(l,p);
        }
}
